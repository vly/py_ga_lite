__title__ = 'GA_lite'
__version__ = '0.0.1'
__author__ = 'Val Lyashov'
__license__ = 'MIT'
__copyright__ = 'Copyright 2012 Val Lyashov'


from . import py_af.py
from . import af_db.py