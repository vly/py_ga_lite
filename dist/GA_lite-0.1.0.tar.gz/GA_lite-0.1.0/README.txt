==========================================
Python Google Analytics API library (lite)
==========================================

A basic Google Analytics API Python library for quick data pulls.
Have used it predominantly in conjunction with iPython notebook and the excellent
Pandas library.